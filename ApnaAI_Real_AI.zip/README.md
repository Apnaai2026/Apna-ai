# Apna AI — real AI version

This project uses an Android client + Node.js backend. The backend calls the OpenAI Responses API.

1. On a server/computer, install Node.js.
2. In `server/`, run `npm install`.
3. Set `OPENAI_API_KEY` as an environment variable. Never put the key in the Android app.
4. Run `npm start`.
5. Change `YOUR-SERVER.example.com` in `MainActivity.kt` to your HTTPS backend URL.
6. Build the Android app in Android Studio.

The OpenAI API uses API keys and OpenAI recommends keeping keys out of client-side apps.
