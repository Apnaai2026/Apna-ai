import express from "express";
import cors from "cors";
import OpenAI from "openai";
const app=express(); app.use(cors()); app.use(express.json());
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.post("/chat", async (req,res)=>{
 try {
  const r=await client.responses.create({model:"gpt-5.6",input:req.body.message});
  res.json(r.output_text);
 } catch(e){ res.status(500).json("AI error"); }
});
app.listen(3000,()=>console.log("Apna AI backend running on :3000"));