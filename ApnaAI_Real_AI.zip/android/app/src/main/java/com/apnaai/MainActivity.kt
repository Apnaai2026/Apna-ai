package com.apnaai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity: ComponentActivity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App() } }
}
@Composable fun App() {
 var text by remember { mutableStateOf("") }
 var answer by remember { mutableStateOf("") }
 var loading by remember { mutableStateOf(false) }
 Column(Modifier.fillMaxSize().padding(16.dp)) {
  Text("🤖 Apna AI", style=MaterialTheme.typography.headlineMedium)
  Spacer(Modifier.height(12.dp))
  LazyColumn(Modifier.weight(1f)) { if(answer.isNotEmpty()) item { Text(answer, Modifier.padding(8.dp)) } }
  Row {
   OutlinedTextField(text,{text=it},Modifier.weight(1f),placeholder={Text("Apna sawaal likho...")})
   Spacer(Modifier.width(8.dp))
   Button(enabled=!loading,onClick={
    val q=text.trim(); if(q.isEmpty()) return@Button
    loading=true
    thread {
     val result=try {
      val c=URL("https://YOUR-SERVER.example.com/chat").openConnection() as HttpURLConnection
      c.requestMethod="POST"; c.doOutput=true; c.setRequestProperty("Content-Type","application/json")
      c.outputStream.use { it.write(("{\"message\":\""+q.replace("\"","\\\"")+"\"}").toByteArray()) }
      c.inputStream.bufferedReader().readText()
     } catch(e:Exception) { "Server connect nahi hua. Backend URL set karo." }
     runOnUiThread { answer=result; loading=false }
    }
    text=""
   }) { Text(if(loading) "..." else "Send") }
  }
 }
}